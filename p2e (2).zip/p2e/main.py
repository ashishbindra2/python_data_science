import re
Pun = {}
Eng = {}
NGRAM = {}
# with open('input/Mapping.txt',encoding='utf-8') as map:
#     map_line = map.readlines()
# for map in map_line:
#     if map:
#         dp1 = map.index('@')
#         sp2,sp1 = map.split('@')
        
#         ltemp2, ltemp1 = [], []
#         ltemp2.append(sp2)        
#         ltemp1.append(sp1)  
        
#         # may be list or string need to check
#         if not Pun.get(sp2):
#             Pun[sp2] = ltemp1
#         else:
#             Pun[sp2] = sp1
#         # print(Pun)
        
#         if not Pun.get(sp1):
#             Pun[sp1] = ltemp2
#         else:
#             Pun[sp1] = sp2 

# with open('input/Result.txt',encoding='utf-8') as MLines:
#     MLines1 = MLines.readlines()
    
# for Mline in MLines1:

#     arr1 = re.split(r'\s+', Mline)
#     if arr1:
#         Dtemp = {}
#         for arr in arr1:
#             if arr.index('_'):
#                 dp1 = arr.index('_')
                
#                 sp1 = arr[:dp1] # dp1+1 may be needed
#                 sp2:int = arr[dp1]
                
#                 Dtemp[sp1]=sp2
            
#         if not NGRAM.get(arr1[0]):
#             NGRAM[arr1[0]] = Dtemp
import os
Pun = {}
Eng = {}
NGRAM = {}
E2PAbbr = {}
P2EAbbr = {}
Cities = []
PNames = []
ENGRAM = {}
PunStops = []
ENames = []

path = os.getcwd()  # Get current working directory

def createDictionaries():

    with open(os.path.join("input/Mapping.txt"), "r",encoding='utf-8') as file:
        for MLine in file:
            if len(MLine.strip()) > 1:
                dp1 = MLine.find('@')
                sp2 = MLine[:dp1]
                sp1 = MLine[dp1 + 1:].strip()
                ltmp1 = [sp1]
                ltmp2 = [sp2]

                if sp2 not in Pun:
                    Pun[sp2] = ltmp1
                else:
                    Pun[sp2].append(sp1)

                if sp1 not in Eng:
                    Eng[sp1] = ltmp2
                else:
                    Eng[sp1].append(sp2)



    with open(os.path.join("input/Result.txt"), "r",encoding='utf-8') as file:
        for MLine in file:
            arr1 = MLine.strip().split()
            
            if len(arr1) > 1:
                Dtmp = {}
                for item in arr1[1:]:
                    if "_" in item:
                        sp1, sp2 = item.split("_")
                        Dtmp[sp1] = int(sp2)
                if arr1[0] not in NGRAM:
                    NGRAM[arr1[0]] = Dtmp


    with open("input/abbr.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            EP = MLine.strip().split("@")
            if len(EP) != 2:
                continue
            if EP[0] not in E2PAbbr:
                E2PAbbr[EP[0]] = EP[1]
            if EP[1] not in P2EAbbr:
                P2EAbbr[EP[1]] = EP[0]


    with open("input/Cities.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            if len(MLine.strip()) > 1:  # Check if line length is greater than 1 after stripping whitespace
                Cities.append(MLine.strip())


    with open("input/Names.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            if len(MLine.strip()) > 1:  # Check if line length is greater than 1 after stripping whitespace
                Cities.append(MLine.strip())


    with open("input/PNames.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            if len(MLine.strip()) > 1:  # Check if line length is greater than 1 after stripping whitespace
                PNames.append(MLine.strip())

    with open("input/PunStops.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            if len(MLine.strip()) > 1:  # Check if line length is greater than 1 after stripping whitespace
                PunStops.append(MLine.strip())


    with open("input/EResult.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            arr1 = MLine.strip().split()
            
            if len(arr1) > 1:
                Dtmp = {}
                for item in arr1[1:]:
                    if "_" in item:
                        sp1, sp2 = item.split("_")
                        Dtmp[sp1] = int(sp2)
                if arr1[0] not in ENGRAM:
                    ENGRAM[arr1[0]] = Dtmp


    with open("input/ENames.txt", "r",encoding='utf-8') as file:
        for MLine in file:
            if len(MLine.strip()) > 1:
                ENames.append(MLine.strip())

    # You can use print() function instead of MessageBox.Show() for console output in Python
    print("Uploaded")

createDictionaries()


def punRefine(str123):
    str123 = str123.replace(".", " . ")
    str123 = str123.replace(",", " , ")
    str123 = str123.replace(":", " : ")
    str123 = str123.replace(";", " ; ")
    str123 = str123.replace("'", " ' ")
    str123 = str123.replace("\"", " \" ")
    str123 = str123.replace("-", " - ")
    str123 = str123.replace("_", " _ ")
    str123 = str123.replace("$", " $ ")
    str123 = str123.replace("%", " % ")
    str123 = str123.replace("।", " । ")
    
    str123 = re.sub(r'[ਂ]+', 'ਂ', str123)
    str123 = re.sub(r'[ੁ]+', 'ੁ', str123)
    str123 = re.sub(r'[ਾ]+', 'ਾ', str123)
    str123 = re.sub(r'[਼]+', '਼', str123)
    str123 = re.sub(r'[ੂ]+', 'ੂ', str123)
    str123 = re.sub(r'[ੇ]+', 'ੇ', str123)
    str123 = re.sub(r'[ੈ]+', 'ੈ', str123)
    str123 = re.sub(r'[ੋ]+', 'ੋ', str123)
    str123 = re.sub(r'[ੌ]+', 'ੌ', str123)
    str123 = re.sub(r'[ੰ]+', 'ੰ', str123)
    str123 = re.sub(r'[ੱ]+', 'ੱ', str123)

    for i in range(2):
        str123 = str123.replace("ੰ੍ਰ", "੍ਰੰ")
        str123 = str123.replace("ਿ੍ਰ", "੍ਰਿ")
        str123 = str123.replace("ਂੈ", "ੈਂ")
        str123 = str123.replace("ੰੁ", "ੁੰ")
        str123 = str123.replace("ੰੂ", "ੂੰ")
        str123 = str123.replace("ੱੁ", "ੁੱ")
        str123 = str123.replace("ੱੂ", "ੂੱ")
        str123 = str123.replace("ੁੂ", "ੂ")
        str123 = str123.replace("ੂੁ", "ੂ")
        str123 = str123.replace("ੋੌ", "ੌ")
        str123 = str123.replace("ੌੋ", "ੌ")
        str123 = str123.replace("ੇੈ", "ੈ")
        str123 = str123.replace("ੈੇ", "ੈ")
    
    str123 = re.sub(r'[\r\n]+', '\r\n', str123)
    str123 = re.sub(r'[ \t]+', ' ', str123)
    str123 = re.sub(r'[ਂ]+', 'ਂ', str123)
    str123 = re.sub(r'[ੁ]+', 'ੁ', str123)
    str123 = re.sub(r'[ਾ]+', 'ਾ', str123)
    str123 = re.sub(r'[਼]+', '਼', str123)
    str123 = re.sub(r'[ੂ]+', 'ੂ', str123)
    str123 = re.sub(r'[ੇ]+', 'ੇ', str123)
    str123 = re.sub(r'[ੈ]+', 'ੈ', str123)
    str123 = re.sub(r'[ੋ]+', 'ੋ', str123)
    str123 = re.sub(r'[ੌ]+', 'ੌ', str123)
    str123 = re.sub(r'[ੰ]+', 'ੰ', str123)
    str123 = re.sub(r'[ੱ]+', 'ੱ', str123)
    str123 = re.sub(r'(\s+)([ਂ਼ਾਿੀੁੂੇੈੋੌ੍ੰੱਾ]+)(?=[ਅ-ਹਖ਼-ਫ਼ੲ-ੴ\s])',r'\1', str123)
    str123 = str123.replace("ਸ਼", "ਸ਼")
    
    return str123
def StrCombine(s1, s2):
    myStr = ""
    l1 = len(s1)
    l2 = len(s2)
    if l1 == 0 or l2 == 0:
        return myStr
    if l1 >= 3 and l2 >= 3 and (s1[-3:] == s2[:3]):
        myStr = s1[:-3] + s2
    elif l1 >= 2 and l2 >= 2 and (s1[-2:] == s2[:2]):
        myStr = s1[:-2] + s2
    elif l1 >= 1 and l2 >= 1 and (s1[-1] == s2[0]):
        myStr = s1[:-1] + s2
    else:
        myStr = s1 + s2
    return myStr

def searchLargestSubStr(s):
    length = 0
    strLength = len(s)
    endStr = s[-1]
    firstStr = s[:-2]
    mystr = ""
    for i in range(strLength - 2):
        mystr = s[:i + 1] + "_" + endStr
        if mystr in PNames:
            length = i
    return length

def gram1(pWord1):
    Len = len(pWord1)
    pWord = pWord1[:-2]
    Len -= 2
    outText = []
    
    if Len == 1:
        first_char = pWord[0]
        if first_char in Pun:
            outText.extend(Pun[first_char])
        else:
            outText.append(first_char)
        return outText
    
    word1 = []
    word2 = []
    
    first = pWord[0]
    if first in Pun:
        word1.extend(Pun[first])
    else:
        word1.append(first)
    
    second = pWord[1]
    if second in Pun:
        word1.extend(Pun[second])
    else:
        word1.append(second)
    
    if not word1:
        word1.append("")
    if not word2:
        word2.append("")
    
    for item1 in word1:
        for item2 in word2:
            outText.append(item1 + item2)
    
    return outText
def gram2(pWord):
    Len = len(pWord)
    outText = []
    Elist = {}
    
    if Len != 4:
        return outText
    
    if pWord in NGRAM:
        Elist = NGRAM[pWord]
        outText.extend(list(Elist.keys()))
    
    if outText:
        return outText
    
    outText = gram1(pWord)
    return outText

def gramN(pWord):
    Len = len(pWord) - 2
    d1 = searchLargestSubStr(pWord) + 1
    if d1 == 1:
        d1 = 2
    d2 = d1 - 1
    d3 = Len - d2
    outText = []
    outText1 = []
    outText2 = []
    Elist = {}
    Elist.clear()
    if pWord in NGRAM:
        Elist = NGRAM[pWord]
        outText.extend(list(Elist.keys()))
    elif pWord[:Len] + "_M" in NGRAM:
        Elist = NGRAM[pWord[:Len] + "_M"]
        outText.extend(list(Elist.keys()))
    elif pWord[:Len] + "_E" in NGRAM:
        Elist = NGRAM[pWord[:Len] + "_E"]
        outText.extend(list(Elist.keys()))
    if outText:
        return outText
    if Len == 1:
        outText = gram1(pWord)
    elif Len == 2:
        outText = gram2(pWord)
    elif Len == 3:
        if "_S" in pWord:
            outText1 = gramN(pWord[:d1] + "_S")
            if pWord[d2 + d3] == "_":
                outText2 = gramN(pWord[d2:d2 + d3] + "_E")
            else:
                outText2 = gramN(pWord[d2:d2 + d3] + "_M")
        elif "_M" in pWord:
            outText1 = gramN(pWord[:d1] + "_M")
            if pWord[d2 + d3] == "_":
                outText2 = gramN(pWord[d2:d2 + d3] + "_E")
            else:
                outText2 = gramN(pWord[d2:d2 + d3] + "_M")
        elif "_E" in pWord:
            outText1 = gramN(pWord[:d1] + "_M")
            outText2 = gramN(pWord[d2:d2 + d3] + "_E")
    elif "_S" in pWord:
        outText1 = gramN(pWord[:d1] + "_S")
        if pWord[d2 + d3] == "_":
            outText2 = gramN(pWord[d2:d2 + d3] + "_E")
        else:
            outText2 = gramN(pWord[d2:d2 + d3] + "_M")
    elif "_M" in pWord:
        outText1 = gramN(pWord[:d1] + "_M")
        if pWord[d2 + d3] == "_":
            outText2 = gramN(pWord[d2:d2 + d3] + "_E")
        else:
            outText2 = gramN(pWord[d2:d2 + d3] + "_M")
    elif "_E" in pWord:
        outText1 = gramN(pWord[:d1] + "_M")
        outText2 = gramN(pWord[d2:d2 + d3] + "_E")
    
    if not outText1:
        outText1.append("")
    if not outText2:
        outText2.append("")
    outT1 = outText1[:100] if len(outText1) > 100 else outText1
    outT2 = outText2[:100] if len(outText2) > 100 else outText2
    
    for item1 in outT1:
        for item2 in outT2:
            outText.append(StrCombine(item1, item2))
    
    return outText

def P2EFun(inStr):
    outStr = ""
    name1 = inStr.split()
    for name2 in name1:
        if name2 in P2EAbbr:
            outStr += P2EAbbr[name2] + " "
            continue
        if len(name2.strip()) < 2:
            continue
        match1 = re.match(r'[A-Z]', name2.upper())
        match2 = re.match(r'[^A-Z]', name2.upper())
        if match1 and not match2:
            continue
        namex = punRefine(name2)
        if " " in namex:
            continue
        name3 = namex + "_S"
        arr = gramN(name3)
        arr1 = list((arr))
        # print(type(arr1),arr1,len(arr1))
        arr2 = arr1
        for arr3 in (arr2):
            if arr3.strip():
                outStr += arr3 + " "
                break
               
        outStr += " "
    return outStr.strip()

ਵਰਡ = "ਡਿੰਪਲ ਰਾਣੀ"
data = P2EFun(ਵਰਡ)
print(data)